### promise .all 



### promise.race

